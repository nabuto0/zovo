const menu2 = (prefix) => {
	return ` Olá seja bem vindo a menu2

COMANDOS:

➛ *${prefix}loli* [off]
➛ *${prefix}loli1*
➛ *${prefix}hentai*
➛ *${prefix}dono*
➛ *${prefix}porno*
➛ *${prefix}boanoite*
➛ *${prefix}bomdia*
➛ *${prefix}boatarde*
➛ *${prefix}mia [aleatórias]*
➛ *${prefix}rize [aleatórias]*
➛ *${prefix}minato [aleatórias]*
➛ *${prefix}boruto [aleatórias]*
➛ *${prefix}hinata [aleatórias]*
➛ *${prefix}sasuke [aleatórias]*
➛ *${prefix}sakura [aleatórias]*
➛ *${prefix}naruto [aleatórias]*
➛ *${prefix}meme*   
➛ *${prefix}lofi*
➛ *${prefix}malkova*
➛ *${prefix}canal*
➛ *${prefix}nsfwloli1*
➛ *${prefix}reislin*
`
}

exports.menu2 = menu2
