const menu3 = (prefix) => {
	return ` Olá seja bem vindo ao menu 3

Comandos:

➛ *${prefix}simih 1 (para ativar)*
➛ *${prefix}simih 0 (para desativar)*
➛ *${prefix}simi (sua mensagem)*
➛

➛
➛ *${prefix}*
➛ *${prefix}*
➛ *${prefix}*
➛

➛
➛ *${prefix}dado*
➛ *${prefix}cekvip*
➛ *${prefix}premiumlist*
➛ *${prefix}delete*
➛ *${prefix}modapk*
➛ *${prefix}indo10*
➛ *${prefix}daftarvip [para virar Premium]*
➛ *${prefix}qrcode*
➛ *${prefix}chentai*
➛ *${prefix}gcpf*
➛ *${prefix}gbin*
➛ *${prefix}pack*
➛ *${prefix}destrava*
➛ *${prefix}gpessoa*

➢【𝗚𝗥𝗨𝗣𝗢】
➛
➛ *${prefix}banir*
➛ *${prefix}leveling [on/off]*
➛ *${prefix}level*
➛ *${prefix}add*
➛ *${prefix}promover*
➛ *${prefix}setfoto [na legenda]*
➛ *${prefix}setname [texto]*
➛ *${prefix}rebaixar*
➛ *${prefix}admins*
➛ *${prefix}marcar*
➛ *${prefix}marcar2*
➛ *${prefix}marcar3*
➛ *${prefix}bemvindo [1/0]*
➛ *${prefix}grupoinfo*
➛ *${prefix}bomdia*
➛ *${prefix}boatarde*
➛ *${prefix}boanoite*
➛ *${prefix}setdesc*
➛ *${prefix}bug [sua mensagem]*
➛
➢【𝗘𝗦𝗣𝗘𝗖𝗜𝗙𝗜𝗖𝗢 𝗗𝗢 𝗕𝗢𝗧】𝗹
➛
➛ *${prefix}bug [sua mensagem]*
➛ *${prefix}clonar [@]*
➛ *${prefix}dono*
➛ *${prefix}ping [ver velocidade do bot]*
➛ *${prefix}termux*
➛ *${prefix}gay [@]*
➛ *${prefix}wame*
➛ *${prefix}map (nome)*
➛ *${prefix}setppbot (marque uma img)*
➛ *${prefix}pinterest (nome)*
➛ *${prefix}desligar (so para o dono)*
➛ *${prefix}timer*
➛
➢【𝗠𝗔𝗜𝗦 𝗔𝗟𝗚𝗨𝗡𝗦】𝗹
➛
➛ *${prefix}neko*
➛ *${prefix}ttp [texto]*
➛ *${prefix}testime*
➛ *${prefix}tomp3*
➛ *${prefix}modoanime [on/off]*
➛ *${prefix}modonsfw [on/off]*
➛ *${prefix}happymod [jogo/app]*
➛ *${prefix}rize*
➛ *${prefix}ytsearch*
➛ *${prefix}moddroid [jogo/app]*
➛ *${prefix}xvideos [titulo]**
➛ *${prefix}nomegp*
➛ *${prefix}nabutojokes (memes aleatórios)*
➛ *${prefix}animecry*
➛ *${prefix}gay1*
➛ *${prefix}next*
➛ *${prefix}alerta*
➛ *${prefix}belle [img aleatórias]*
➛ *${prefix}pronomeneu [texto]*
➛ *${prefix}hobby*
➛ *𝗡𝗢𝗠𝗘: nabuto
➛ *𝗪𝗣𝗣: wa.me/+556993733829
【 NABUTO 】
➢【 𝗖𝗢𝗠𝗔𝗡𝗗𝗢𝗦 𝗗𝗘 𝗠𝗨𝗦𝗜𝗖𝗔 】

➛ *${prefix} em teste
➛ *${prefix}jogaroxo*
➛ *${prefix} em teste
➛ *${prefix} em teste
➛ *${prefix}narutinho*
➛ *${prefix}}tobi*
➛ *${prefix}rapL*
➛ *${prefix}paypal*
➛ *${prefix}sad*

➢【 𝗢𝗨𝗧𝗥𝗢𝗦 /2 】

*➛ *${prefix}antilink [1/0]*
*➛ *${prefix}brainly [pergunta]*
➛ *${prefix}antiracismo [on/off]*
➛ *${prefix}setnomebot*
➛ *${prefix}meme*

➢【 𝗜𝗡𝗧𝗘𝗥𝗔𝗧𝗜𝗩𝗢𝗦 】

NOTA »
Mandar a msg sem o prefixo


➛ *${prefix} *beat1*
➛ *${prefix} *beat2*
➛ *${prefix} *hentaisom* (erro)

➢【 𝗗𝗢𝗡𝗢 】

 *𝗡𝗢𝗠𝗘: nabuto
 *𝗪𝗣𝗣: wa.me/+556993733829




【 NABUTO 】`
}

exports.menu3 = menu3
