const menu = (prefix) => {
	return ` OLÁ, O BOT ESTÁ ASSIM POIS FICAM MAIS ORGANIZADO!

CANAL: https://youtube.com/channel/UCZEtf9AlsC2zsJQwrfW-44w

WHATSAPP DO DONO: wa.me/556993733829


ESCOLHA:

🇧🇷 *${prefix}menu1*



🇧🇷 *${prefix}menu2*



🇧🇷 *${prefix}menu3*















































































OBS: SE FOR ENTRAR EM ALGUM GRUPO DO BOT VOU COLOCAR LOGO AS REGRAS AQUI E SUAS PUNIÇÕES:

REGRA NÚMERO 1- LINKS OU OFENSAS COM INTENÇÕES MALICIOSAS = *SUJEITO A DESATIVANDO DO SEU CHIP*

REGRA NÚMERO 2- RESPEITO/NÃO PEDIR ADM/TRAVAS/FLOOD/GADO/TRAVAS. 




CANAL: https://youtube.com/channel/UCZEtf9AlsC2zsJQwrfW-44w

WHATSAPP DO DONO: wa.me/556993733829

GRUPOS NO WHATSAPP:

GRUPO 1- https://chat.whatsapp.com/J2ZGIuyEx1hAUmjjIqXZD5

GRUPO 2- https://chat.whatsapp.com/DFmKl2MyPZvDzgDZIWr6l0

GRUPO 3-  https://chat.whatsapp.com/K4cxpXdIFyLIfA41J2oGM1

[GRUPO 3 CRIADO RECENTEMENTE] `
}

exports.menu = menu





