const menu1 = (prefix) => {
	return ` Olá, aqui está o menu primário, seja bem vindo(a)😁

MENU:

➛ *${prefix}Sticker* [Faz figurinha]
➛ *${prefix}play* [nome da música]
➛ *${prefix}toimg* [converter figurinha em imagem]
➛ *${prefix}wame* [link do seu whatsapp]
➛ *${prefix}meme* [memes aleatórios]
➛ *${prefix}nabutojokes* [memes2]
➛ *${prefix}tts pt* [seu texto]
➛ *${prefix}ping* [velocidade]
➛ *${prefix}owner ou dono* [info do criador]

         

➛ *${prefix}animecry*
➛ *${prefix}chentai [premium]*
➛ *${prefix}gcpf [premium]*
➛ *${prefix}gay [@]*
➛ *${prefix}gbin [premium]*
➛ *${prefix}pack [premium]*
➛ *${prefix}destrava [premium]*
➛ *${prefix}gpessoa [premium]*
➛ *${prefix}spamcall*
➛ *${prefix}play (nome da msc)*



➛ *${prefix}closegc* [fechar grupo]
➛ *${prefix}opengc* [abrir grupo]
➛ *${prefix}antilink* 1 [anti link]
➛ *${prefix}antiracismo on* [anti racismo]
➛ *${prefix}banir* [banir membro]
➛ *${prefix}admins* [lista se administradores]
➛ *${prefix}marcar* [marcar todos membros]
➛ *${prefix}linkgp* [link do grupo]
➛ *${prefix}promover* [dar adm]
➛ *${prefix}rebaixar* [tirar adm]
➛ *${prefix}bemvindo* 1 [recusso de boas vindas]
➛ *${prefix}grupoinfo* [info]
➛ *${prefix}setdesc* [trocar descrição]
➛ *${prefix}setfoto* [mudar foto]
➛ *${prefix}porno* [porno]
➛ *${prefix}mia* [fotos da mia]


➛
➛ *${prefix}figu*
➛ *${prefix}toimg*
➛ *${prefix}nabutojokes (memes aleatórios)*
➛ *${prefix}memeindo*
➛ *${prefix}tts*
➛ *${prefix}lolih [on]*
➛ *${prefix}nsfwloli [off]*
➛ *${prefix}url2img*
➛ *${prefix}leens [na legenda]*
➛ *${prefix}wait [na legenda]*
➛ *${prefix}setprefix*
➛
APENAS PARA GRUPO:
➛
➛ *${prefix}linkgp*
➛ *${prefix}simih [1/0]*
➛ *${prefix}marcar*
➛ *${prefix}add [@]*
➛ *${prefix}banir [@]*
➛ *${prefix}promover [@]*
➛ *${prefix}rebaixar*
➛ *${prefix}admins*
➛ *${prefix}marcar2*
➛ *${prefix}bc [texto]* (ele faz uma ™)
➛ *${prefix}marcar3*
➛ *${prefix}bloqueados*
➛ *${prefix}bloquear [@]*
➛ *${prefix}desbloquear [@]*
➛ *${prefix}limpar*
➛ *${prefix}bc [ *texto* ]*
➛ *${prefix}bemvindo [1/0]*
➛ *${prefix}clonar [@]*
➛ *${prefix}help1*
➛ *${prefix}dono*
➛ *${prefix}owner*
➛ *${prefix}tts [texto]*
➛ *${prefix}setnome*
➛ *${prefix}termux*
➛ *${prefix}setfoto*
➛ *${prefix}grupoinfo*
➛ *${prefix}ytmp4*
➛ *${prefix}bomdia*
➛ *${prefix}boanoite*
➛ *${prefix}marcar*
➛ *${prefix}marcar2*
➛ *${prefix}marcar3*
`
}

exports.menu1 = menu1
